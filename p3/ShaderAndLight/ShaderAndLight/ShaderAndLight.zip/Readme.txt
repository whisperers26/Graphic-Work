Exactly the same as requirement:
	alt + mouse to control camera
	wasduj to control selected light
	1,2 to switch selected light