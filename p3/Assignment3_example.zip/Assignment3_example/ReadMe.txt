Press '1' or '2' on the keyboard to select one of the two lights (red spheres). The selected one is changed to a solid mesh, and the other one is a wireframe mesh.

Press 'wasd' to move the selected light on the xz plane, and press 'u' and 'j' to move the selected light along the y axis. 

Alt+LMB rotates the camera, Alt+MMB pans the camera, and Alt+RMB zooms the camera. 
