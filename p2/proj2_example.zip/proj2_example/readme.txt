Usage: 
Up arrow key goes to a child part.
Down arrow key goes to the parent part.
Left and right arrow keys cycle the neighbor parts. 
A and D keys rotate the current selected part. 