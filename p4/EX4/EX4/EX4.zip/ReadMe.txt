Press '+' or '-' on the keyboard to double or reduce by half the resoulution. The resolution can be increased up to 8192 x 4096 and reduced no less than 16 x 8. 

Press 'wasd' to move the green wireframe sphere on the xz plane, and press 'u' and 'j' to move it along the y axis. 

Alt+LMB rotates the camera, Alt+MMB pans the camera, and Alt+RMB zooms the camera. 

The on-screen text "# of Particles" shows the total number of particles processed and rendered by the shaders in real-time. 
