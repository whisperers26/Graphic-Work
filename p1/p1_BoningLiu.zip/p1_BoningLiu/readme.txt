left click to draw

right click to open menu

enter to finish line/polygon
